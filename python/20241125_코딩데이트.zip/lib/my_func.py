

# my_func.py

def my_print(string):
    print('>>', string)

class Champion:
    ### Static Variable
    game_end = False

    def __init__(self, name='아트록스', hp=100, ad=10):
        self.name = name
        self.hp = hp
        self.ad = ad

    def attack(self, enemy):
        enemy.hp -= self.ad
        my_print(f'{self.name}이(가) {enemy.name}을(를) 공격합니다.')



me = Champion('이즈리얼', 30, 30)
enemy = Champion('아트록스', 100, 10)

Champion.game_end = True 

# me.game_end = True # self.game_end = True

print(me.game_end)      # True 공유하는 변수
print(enemy.game_end)   # True
all_player = [me, enemy1, enemy2, enemy3, enemy4, enemy5]

while is_game_peinding():
    for cur_play in all_player:
        if is_nexus_destroyed(cur_play):
            Champion.game_end = True

        if Champion.game_end:
            go_to_looby()
