

# ROS1 VS ROS2

# python

'''
1. class ?
2. self. ? V
3. 전체로직
4. from import vs import
'''


#
# def attack(me_damage, you_hp):
#     you_hp = you_hp - me_damage
#     # you_hp 변수는 함수 종료시 사라진다.
#     return you_hp
#
# attack(10, 100) #

# def get_waypoints():
#     return 2
def input_num(): # definition
    return 3

def generate_sinusoide_path():
    return np.array([1, 2, 3, 4, 5])

def generate_x_path():
    return np.array([3, 3, 2, 5, 5])

def generate_sinusoide_path():
    return np.array([1, 2, 3, 4, 5])

class ReferencePath:
    # 소멸자 
    def __init__(self, waypoints): # 생성자
        self.waypoints = waypoints
        # self.get_waypoints = 4 # 미친 짓 (함수 이름 != 변수 이름)
        # self.value1 = 0
        # self.value1 = 0

        # self.value1 = self.get_waypoints()   # result : 1
        # self.value2 = get_waypoints()        # result : 2
        # return 못씀

    # 멤버 함수
    def get_waypoints(self):
        return self.waypoints

    def print_value(self):
        print(self.value1)
        print(self.value1)

num = 3 # declaration

num = input_num() # declaration

input_num() # declaration


rp = ReferencePath( generate_sinusoide_path() ) # __init__ 실행



waypoints = path.get_waypoints()
path.waypoints
print(waypoints)
print(path.get_waypoints())

'''
1. 가독성 
2. 코드 재사용
'''



# print(path.print_value)

#
# # 영어 문법 처럼 코드짜고 싶다.
#
# print(you_hp)
#
# me = Champion()
#
# you = Champion('이즈리얼', 30, 30)
#
# print(me.pick)
# print(you.pick)
#
# me.attack(you) # s v o
#
# print(you.hp)
#
#

import lib.my_func

charactor = lib.my_func.Champion('이즈리얼', 30, 30)
enemy = lib.my_func.Champion('아트록스', 100, 10)
charactor.attack(enemy)

from lib.my_func import Champion, 

charactor = Champion('이즈리얼', 30, 30)
enemy = Champion('아트록스', 100, 10)
charactor.attack(enemy)


# from my_func import my_print, Champion
#
# path = numpy.array()
# np.array
# my_func.my_print('hello')
#
# me = Champion('이즈리얼', 30, 30)
# you = Champion('아트록스', 100, 10)
# me.attack(you)
# #
